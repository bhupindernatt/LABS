document.addEventListener("DOMContentLoaded", function() {
    // Task 1: Change text of paragraph on button click
    var changeTextBtn = document.getElementById("changeTextBtn");
    let messageParagraph = document.getElementById("message");
    
    changeTextBtn.addEventListener("click", function() {
        messageParagraph.textContent = "Text changed successfully!";
    });

    // Task 2: Change background color of body on page load
    var body = document.body;
    var randomColor = getRandomColor();
    body.style.backgroundColor = randomColor;

    // Task 3: Append a new paragraph to the container on page load
    var container = document.getElementById("container");
    var newParagraph = document.createElement("p");
    newParagraph.textContent = "New paragraph added dynamically!";
    container.appendChild(newParagraph);
});

// Function to generate a random color
function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}
